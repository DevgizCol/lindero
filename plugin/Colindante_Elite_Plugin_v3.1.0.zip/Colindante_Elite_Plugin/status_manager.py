# -*- coding: utf-8 -*-
import json
import os
import tempfile
import datetime

class StatusManager:
    """
    Gestor de Estado Centralizado para Colindante Elite.
    Mantiene sincronizado el estado del proceso entre el núcleo (AI Core) y la interfaz (Wizard/Dashboard).
    """
    
    def __init__(self):
        self.status = {
            'state': 'IDLE', # IDLE, RUNNING, PAUSED, COMPLETED, ERROR
            'progress': 0,
            'current_task': 'Esperando inicio...',
            'stats': {
                'predios_processed': 0,
                'total_predios': 0,
                'segments_analyzed': 0,
                'errors_detected': 0,
                'elapsed_seconds': 0,
                'eta_seconds': 0,
                'speed': 0.0
            },
            'current_step': None, # Información de lupa del segmento actual
            'logs': [],
            'history': [],
            'last_update': None,
            'current_geometry': None # GeoJSON del predio actual
        }
        self.status_file = os.path.join(tempfile.gettempdir(), 'colindante_elite_status.json')
        self._load_history_cache()
        self._save()

    def _load_history_cache(self):
        try:
            hist_file = os.path.join(tempfile.gettempdir(), 'colindante_elite_history.json')
            if os.path.exists(hist_file):
                with open(hist_file, 'r', encoding='utf-8') as f:
                    self.status['history'] = json.load(f)
        except:
            self.status['history'] = []

    def start_analysis(self, total_predios=1):
        self.status['state'] = 'RUNNING'
        self.status['progress'] = 0
        self.status['current_task'] = 'Iniciando motores espaciales...'
        self.status['stats'] = {
            'predios_processed': 0,
            'total_predios': total_predios,
            'segments_analyzed': 0,
            'errors_detected': 0,
            'elapsed_seconds': 0,
            'eta_seconds': 0,
            'speed': 0.0
        }
        self.status['logs'] = []
        self.status['current_step'] = None
        self.add_log("Análisis iniciado con motor de precisión milimétrica", "info")
        self._save()

    def update_status(self, predios=None, total_predios=None, segments=None, errors=None, progress=None, 
                      task=None, current_geometry=None, elapsed=None, eta=None, speed=None, state=None):
        if predios is not None: self.status['stats']['predios_processed'] = predios
        if total_predios is not None: self.status['stats']['total_predios'] = total_predios
        if segments is not None: self.status['stats']['segments_analyzed'] = segments
        if errors is not None: self.status['stats']['errors_detected'] = errors
        if elapsed is not None: self.status['stats']['elapsed_seconds'] = elapsed
        if eta is not None: self.status['stats']['eta_seconds'] = eta
        if speed is not None: self.status['stats']['speed'] = speed
        if progress is not None: self.status['progress'] = progress
        if task is not None: self.status['current_task'] = task
        if state is not None: self.status['state'] = state
        if current_geometry is not None: self.status['current_geometry'] = current_geometry
        
        self._save()

    def update_step(self, step_info):
        """Actualiza la información de la lupa para visualización paso a paso"""
        self.status['current_step'] = step_info
        self._save()

    def add_log(self, message, level='info'):
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        self.status['logs'].append({
            'time': timestamp,
            'msg': message,
            'level': level
        })
        if len(self.status['logs']) > 150:
            self.status['logs'].pop(0)
        self._save()

    def add_history_record(self, record):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        record['timestamp'] = timestamp
        self.status['history'].insert(0, record)
        if len(self.status['history']) > 50:
            self.status['history'].pop()
        try:
            hist_file = os.path.join(tempfile.gettempdir(), 'colindante_elite_history.json')
            with open(hist_file, 'w', encoding='utf-8') as f:
                json.dump(self.status['history'], f, ensure_ascii=False)
        except:
            pass
        self._save()

    def get_logs(self):
        return self.status.get('logs', [])

    def get_history(self):
        return self.status.get('history', [])

    def get_status_file_path(self):
        return self.status_file

    def get_status(self):
        return self.status

    def _save(self):
        self.status['last_update'] = datetime.datetime.now().isoformat()
        try:
            with open(self.status_file, 'w', encoding='utf-8') as f:
                json.dump(self.status, f, ensure_ascii=False)
        except Exception as e:
            pass

# Instancia Global (Singleton)
status_manager = StatusManager()

