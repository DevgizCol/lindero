# -*- coding: utf-8 -*-
import http.server
import socketserver
import json
import os
import uuid
import threading
from urllib.parse import urlparse, parse_qs

class SimpleHandler(http.server.SimpleHTTPRequestHandler):
    """
    Manejador de Peticiones HTTP para el Dashboard 'God Mode' y API Local de Colindante Elite.
    """
    api_key = str(uuid.uuid4())[:8]
    status_manager_ref = None
    latest_report_path = None
    
    def send_cors_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-API-Key')

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_cors_headers()
        self.end_headers()

    def do_GET(self):
        parsed_url = urlparse(self.path)
        path = parsed_url.path
        
        # 1. Endpoint de Estado (JSON)
        if path == '/api/status':
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.send_cors_headers()
            self.end_headers()
            
            if self.status_manager_ref:
                status_data = self.status_manager_ref.get_status()
                self.wfile.write(json.dumps(status_data, ensure_ascii=False).encode('utf-8'))
            else:
                self.wfile.write(json.dumps({'error': 'No Status Manager linked'}).encode('utf-8'))
            return

        # 2. Endpoint de Logs (JSON)
        if path == '/api/logs':
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.send_cors_headers()
            self.end_headers()
            
            logs = self.status_manager_ref.get_logs() if self.status_manager_ref else []
            self.wfile.write(json.dumps({'logs': logs}, ensure_ascii=False).encode('utf-8'))
            return

        # 3. Endpoint de Historial (JSON)
        if path == '/api/history':
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.send_cors_headers()
            self.end_headers()
            
            history = self.status_manager_ref.get_history() if self.status_manager_ref else []
            self.wfile.write(json.dumps({'history': history}, ensure_ascii=False).encode('utf-8'))
            return

        # 4. Endpoint de Chatbot Catastral (JSON)
        if path in ['/api/chat', '/api/chatbot']:
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.send_cors_headers()
            self.end_headers()
            
            qs = parse_qs(parsed_url.query)
            msg = qs.get('message', [''])[0].strip().lower()
            
            response_text = self._generate_chatbot_reply(msg)
            self.wfile.write(json.dumps({
                'response': response_text,
                'author': 'Colindante GPT',
                'status': 'success'
            }, ensure_ascii=False).encode('utf-8'))
            return

        # 5. Favicon
        if path == '/favicon.ico':
            self.send_response(204)
            self.end_headers()
            return

        # 6. Reporte Notarial HTML Generado
        if path == '/report':
            if self.latest_report_path and os.path.exists(self.latest_report_path):
                self.send_response(200)
                self.send_header('Content-type', 'text/html; charset=utf-8')
                self.send_cors_headers()
                self.end_headers()
                try:
                    with open(self.latest_report_path, 'rb') as f:
                        self.wfile.write(f.read())
                except Exception as e:
                    self.wfile.write(f"Error reading report: {e}".encode('utf-8'))
            else:
                self.send_response(404)
                self.send_header('Content-type', 'text/html; charset=utf-8')
                self.end_headers()
                self.wfile.write(b"<h1>Reporte no encontrado</h1><p>Aun no se ha completado ningun analisis.</p>")
            return

        # 7. Dashboard 3D Web
        if path == '/dashboard':
            self.send_dashboard()
            return

        # 8. Documentacion Oficial (Root)
        if path in ['/', '/index', '/index.html']:
            self.send_index()
            return

        # Fallback a archivos estáticos locales dentro de la carpeta help
        help_dir = os.path.join(os.path.dirname(__file__), 'help')
        requested_file = os.path.normpath(os.path.join(help_dir, path.lstrip('/')))
        if requested_file.startswith(help_dir) and os.path.exists(requested_file) and not os.path.isdir(requested_file):
            self.send_response(200)
            if requested_file.endswith('.css'): self.send_header('Content-type', 'text/css')
            elif requested_file.endswith('.js'): self.send_header('Content-type', 'application/javascript')
            elif requested_file.endswith('.html'): self.send_header('Content-type', 'text/html; charset=utf-8')
            elif requested_file.endswith('.png'): self.send_header('Content-type', 'image/png')
            elif requested_file.endswith('.svg'): self.send_header('Content-type', 'image/svg+xml')
            self.send_cors_headers()
            self.end_headers()
            with open(requested_file, 'rb') as f:
                self.wfile.write(f.read())
            return

        # Default
        super().do_GET()

    def _generate_chatbot_reply(self, msg):
        if not msg:
            return "¡Hola! Soy Colindante GPT. Puedo ayudarte con dudas sobre linderos, cálculo de áreas, tolerancia de cierre y validación catastral."
        if "cierre" in msg or "error" in msg:
            return "La tolerancia de cierre perimetral en Colindante Elite es de 0.10 metros (10 cm). Si la suma de tramos difiere del perímetro del polígono por más de este valor, se genera una alerta forense."
        if "snap" in msg or "contacto" in msg:
            return "El algoritmo de Fase 1 aplica un snap de 0.03 m (3 cm) sobre la capa de TERRENO. Si dos predios comparten frontera, se asigna con 100% de confianza antes de proyectar franjas hacia vías."
        if "frente" in msg or "orientacion" in msg:
            return "La orientación notarial sitúa al observador en el frente del predio mirando hacia el centroide. Los costados Derecho e Izquierdo se definen según su campo visual, y el Fondo es el extremo opuesto."
        if "reporte" in msg:
            return "El reporte final incluye certificación perimetral, desglose milimétrico por tramos, azimuts, coordenadas y texto estructurado listo para minutas notariales."
        return f"Entendido: '{msg}'. El sistema está monitoreando las geometrías en tiempo real con precisión milimétrica y validación topológica continua."

    def send_dashboard(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html; charset=utf-8')
        self.send_cors_headers()
        self.end_headers()
        dash_path = os.path.join(os.path.dirname(__file__), 'help', 'dashboard.html')
        if os.path.exists(dash_path):
            with open(dash_path, 'rb') as f:
                self.wfile.write(f.read())
        else:
            self.wfile.write(b"<h1>Dashboard en preparacion</h1>")

    def send_index(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html; charset=utf-8')
        self.send_cors_headers()
        self.end_headers()
        index_path = os.path.join(os.path.dirname(__file__), 'help', 'index.html')
        if os.path.exists(index_path):
            with open(index_path, 'rb') as f:
                self.wfile.write(f.read())
        else:
            self.wfile.write(b"<h1>Documentacion en preparacion</h1>")

    def log_message(self, format, *args):
        return

class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class ServerController:
    """Controlador Singleton para el servidor HTTP local"""
    def __init__(self):
        self.server = None
        self.port = 8000
        self.url = f"http://127.0.0.1:{self.port}"

    def start(self, status_manager):
        if self.server: return
        
        SimpleHandler.status_manager_ref = status_manager
        for attempt_port in range(8000, 8015):
            try:
                self.port = attempt_port
                self.url = f"http://127.0.0.1:{self.port}"
                self.server = ThreadingHTTPServer(('127.0.0.1', self.port), SimpleHandler)
                thread = threading.Thread(target=self.server.serve_forever)
                thread.daemon = True
                thread.start()
                break
            except OSError:
                continue

    def set_latest_report(self, path):
        SimpleHandler.latest_report_path = path

    def get_url(self):
        return f"{self.url}/dashboard"

    def get_report_url(self):
        return f"{self.url}/report"

http_server = ServerController()
