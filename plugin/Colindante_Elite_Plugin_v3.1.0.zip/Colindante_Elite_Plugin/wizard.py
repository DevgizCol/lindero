# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import Qt, QSize, QTimer, QPropertyAnimation, QEasingCurve
from qgis.PyQt.QtGui import QIcon, QColor, QFont, QPainter, QPen, QBrush, QLinearGradient
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QStackedWidget, QWidget, QFrame, QComboBox, QLineEdit, 
    QProgressBar, QTextEdit, QGridLayout, QMessageBox, QSizePolicy, 
    QApplication, QSplitter, QGroupBox, QCheckBox, QScrollArea,
    QGraphicsDropShadowEffect, QSpacerItem
)
from qgis.gui import QgsMapCanvas, QgsRubberBand
from qgis.core import QgsProject, QgsVectorLayer, QgsWkbTypes
import os
import webbrowser
import traceback
from .ai_core import AICore

# ──────────────────────────────────────────────────────────────────────────────
# PALETA DE COLORES PREMIUM: OBSIDIAN SAPPHIRE (Refinada y Equilibrada)
# ──────────────────────────────────────────────────────────────────────────────
STYLESHEET = """
/* ─── GLOBAL ─── */
QDialog#EliteWizardDialog {
    background-color: #0a0f1c;
    color: #e2e8f0;
    font-family: 'Segoe UI', 'Outfit', sans-serif;
    font-size: 10pt;
}

QWidget { outline: none; }

QScrollArea { 
    background: transparent; 
    border: none; 
}
QScrollArea > QWidget > QWidget { 
    background: transparent; 
}
QScrollBar:vertical {
    background: #0d1424;
    width: 6px;
    border-radius: 3px;
}
QScrollBar::handle:vertical {
    background: #1e3a5f;
    border-radius: 3px;
    min-height: 30px;
}
QScrollBar::handle:vertical:hover {
    background: #2563eb;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }

/* ─── TYPOGRAPHY ─── */
QLabel { color: #94a3b8; font-size: 10pt; }
QLabel#HeaderTitle { 
    font-size: 20pt; font-weight: 900; color: #ffffff; 
    letter-spacing: 1.5px; 
}
QLabel#HeaderSubtitle { 
    font-size: 9pt; color: #60a5fa; font-weight: 700; 
    letter-spacing: 1px; text-transform: uppercase; 
}
QLabel#SectionTitle { 
    font-size: 13pt; font-weight: 800; color: #ffffff; 
    margin-bottom: 4px; padding-bottom: 4px; 
    border-bottom: 1px solid rgba(37, 99, 235, 0.3); 
}
QLabel#Attribution { font-size: 8pt; color: #475569; font-style: italic; }
QLabel#StepLabel { 
    font-size: 8.5pt; color: #64748b; font-weight: 600; 
}
QLabel#StepLabelActive { 
    font-size: 8.5pt; color: #60a5fa; font-weight: 700; 
}

/* ─── INPUTS & COMBOBOX ─── */
QComboBox, QLineEdit {
    background-color: #111827;
    border: 1px solid #1e293b;
    border-radius: 5px;
    padding: 7px 10px;
    color: #f8fafc;
    font-size: 9.5pt;
    min-height: 16px;
    selection-background-color: #2563eb;
    selection-color: #fff;
}
QComboBox:hover, QLineEdit:focus { 
    border: 1px solid #2563eb; 
    background-color: #131b2e; 
}
QComboBox::drop-down { border: none; padding-right: 6px; }
QComboBox QAbstractItemView {
    background-color: #111827;
    color: #f8fafc;
    border: 1px solid #1e293b;
    selection-background-color: #2563eb;
}

/* ─── BUTTONS ─── */
QPushButton {
    background-color: #131b2e;
    color: #e2e8f0;
    border: 1px solid #1e293b;
    border-radius: 5px;
    padding: 7px 14px;
    font-weight: 700;
    font-size: 9pt;
    min-height: 18px;
}
QPushButton:hover { 
    background-color: #1e293b; 
    border-color: #3b82f6; 
    color: #ffffff; 
}
QPushButton:pressed {
    background-color: #0f172a;
}
QPushButton#PrimaryBtn {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #2563eb, stop:1 #3b82f6);
    color: #ffffff;
    border: none;
    font-weight: 800;
    font-size: 9.5pt;
    padding: 9px 20px;
}
QPushButton#PrimaryBtn:hover { 
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #3b82f6, stop:1 #60a5fa); 
}
QPushButton#DestructiveBtn { 
    color: #f87171; 
    border-color: #7f1d1d; 
    background: transparent; 
}
QPushButton#DestructiveBtn:hover { 
    background-color: #dc2626; 
    color: #ffffff; 
    border-color: #dc2626;
}
QPushButton#ActionBtn {
    background-color: #1e3a5f;
    color: #ffffff;
    border: 1px solid #2563eb;
    border-radius: 5px;
    padding: 7px 12px;
    font-weight: 700;
}
QPushButton#ActionBtn:hover { background-color: #1d4ed8; }
QPushButton#GreenBtn {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #059669, stop:1 #10b981);
    color: #ffffff;
    border: none;
    border-radius: 5px;
    padding: 7px 14px;
    font-weight: 700;
}
QPushButton#GreenBtn:hover { background-color: #047857; }
QPushButton:disabled {
    background-color: #0f172a;
    color: #334155;
    border-color: #1e293b;
}

/* ─── CONTAINERS & CARDS ─── */
QFrame#Card { 
    background-color: #0f172a; 
    border: 1px solid #1e293b; 
    border-radius: 8px; 
}
QFrame#NavBar {
    background-color: #070b14;
    border-top: 1px solid #1e293b;
}
QGroupBox {
    color: #60a5fa;
    font-weight: 700;
    font-size: 9.5pt;
    border: 1px solid #1e293b;
    border-radius: 6px;
    margin-top: 8px;
    padding-top: 12px;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 5px;
}

/* ─── PROGRESS & METRICS ─── */
QProgressBar { 
    border: none; 
    background-color: #111827; 
    height: 6px; 
    border-radius: 3px; 
    text-align: right;
    font-size: 0px;
}
QProgressBar::chunk { 
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #2563eb, stop:1 #10b981); 
    border-radius: 3px; 
}

QTextEdit { 
    background-color: #060910; 
    border: 1px solid #1e293b; 
    color: #34d399; 
    font-family: 'Consolas', 'JetBrains Mono', monospace; 
    font-size: 8.5pt; 
    border-radius: 5px;
    padding: 4px;
}

QCheckBox {
    color: #cbd5e1;
    font-weight: 600;
    font-size: 9pt;
    spacing: 6px;
}
QCheckBox::indicator {
    width: 14px;
    height: 14px;
    border-radius: 3px;
    border: 1px solid #334155;
    background: #111827;
}
QCheckBox::indicator:checked {
    background-color: #2563eb;
    border-color: #2563eb;
}

/* ─── STEP INDICATOR ─── */
QFrame#StepIndicator {
    background-color: #070b14;
    border-bottom: 1px solid #1e293b;
    min-height: 36px;
    max-height: 36px;
}
QFrame#StepDot {
    min-width: 22px; max-width: 22px;
    min-height: 22px; max-height: 22px;
    border-radius: 11px;
    background-color: #1e293b;
    color: #475569;
    font-size: 8pt;
    font-weight: 800;
}
QFrame#StepDotActive {
    min-width: 22px; max-width: 22px;
    min-height: 22px; max-height: 22px;
    border-radius: 11px;
    background-color: #2563eb;
    color: #ffffff;
    font-size: 8pt;
    font-weight: 800;
}
QFrame#StepDotDone {
    min-width: 22px; max-width: 22px;
    min-height: 22px; max-height: 22px;
    border-radius: 11px;
    background-color: #059669;
    color: #ffffff;
    font-size: 8pt;
    font-weight: 800;
}
QFrame#StepLine {
    background-color: #1e293b;
    min-height: 2px; max-height: 2px;
    min-width: 24px;
}
QFrame#StepLineDone {
    background-color: #059669;
    min-height: 2px; max-height: 2px;
    min-width: 24px;
}
"""


# ──────────────────────────────────────────────────────────────────────────────
# STEP INDICATOR WIDGET (Barra visual de progreso por pasos)
# ──────────────────────────────────────────────────────────────────────────────
class StepIndicator(QFrame):
    """Barra visual de pasos del wizard con indicadores circulares"""
    
    STEP_NAMES = ["Inicio", "Capas", "Campos", "Ejecución"]
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("StepIndicator")
        self.current_step = 0
        self._build()
    
    def _build(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 6, 16, 6)
        layout.setSpacing(0)
        layout.addStretch(1)
        
        self.dots = []
        self.lines = []
        self.labels = []
        
        for i, name in enumerate(self.STEP_NAMES):
            # Dot + Label Column
            col = QVBoxLayout()
            col.setSpacing(2)
            col.setAlignment(Qt.AlignCenter)
            
            dot = QLabel(str(i + 1))
            dot.setFixedSize(22, 22)
            dot.setAlignment(Qt.AlignCenter)
            dot.setObjectName("StepDotActive" if i == 0 else "StepDot")
            self.dots.append(dot)
            
            lbl = QLabel(name)
            lbl.setAlignment(Qt.AlignCenter)
            lbl.setObjectName("StepLabelActive" if i == 0 else "StepLabel")
            self.labels.append(lbl)
            
            col.addWidget(dot, 0, Qt.AlignCenter)
            col.addWidget(lbl, 0, Qt.AlignCenter)
            layout.addLayout(col)
            
            # Line between dots
            if i < len(self.STEP_NAMES) - 1:
                line = QFrame()
                line.setObjectName("StepLine")
                line.setFixedHeight(2)
                line.setMinimumWidth(24)
                line.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
                self.lines.append(line)
                layout.addWidget(line, 0, Qt.AlignVCenter)
        
        layout.addStretch(1)
    
    def set_step(self, step):
        self.current_step = step
        for i, (dot, lbl) in enumerate(zip(self.dots, self.labels)):
            if i < step:
                dot.setObjectName("StepDotDone")
                dot.setText("✓")
                lbl.setObjectName("StepLabel")
            elif i == step:
                dot.setObjectName("StepDotActive")
                dot.setText(str(i + 1))
                lbl.setObjectName("StepLabelActive")
            else:
                dot.setObjectName("StepDot")
                dot.setText(str(i + 1))
                lbl.setObjectName("StepLabel")
            # Force style refresh
            dot.style().unpolish(dot)
            dot.style().polish(dot)
            lbl.style().unpolish(lbl)
            lbl.style().polish(lbl)
        
        for i, line in enumerate(self.lines):
            line.setObjectName("StepLineDone" if i < step else "StepLine")
            line.style().unpolish(line)
            line.style().polish(line)


# ──────────────────────────────────────────────────────────────────────────────
# BASE PAGE
# ──────────────────────────────────────────────────────────────────────────────
class WizardPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout()
        self.layout.setContentsMargins(20, 16, 20, 12)
        self.layout.setSpacing(10)
        self.setLayout(self.layout)

    def add_title(self, text):
        lbl = QLabel(text)
        lbl.setObjectName("SectionTitle")
        self.layout.addWidget(lbl)

    def add_card(self, widget):
        frame = QFrame()
        frame.setObjectName("Card")
        fl = QVBoxLayout()
        fl.setContentsMargins(14, 14, 14, 14)
        fl.addWidget(widget)
        frame.setLayout(fl)
        self.layout.addWidget(frame)

    def validate(self):
        return True


# ──────────────────────────────────────────────────────────────────────────────
# PAGE 1: WELCOME
# ──────────────────────────────────────────────────────────────────────────────
class WelcomePage(WizardPage):
    def __init__(self):
        super().__init__()
        self.layout.setContentsMargins(20, 10, 20, 10)
        
        # Hero Section (compacto)
        hero = QWidget()
        hl = QVBoxLayout()
        hl.setSpacing(2)
        hl.setContentsMargins(0, 0, 0, 0)
        
        title = QLabel("COLINDANTE ELITE")
        title.setObjectName("HeaderTitle")
        title.setAlignment(Qt.AlignCenter)
        
        sub = QLabel("SISTEMA DE INTELIGENCIA TERRITORIAL • ALTA PRECISIÓN")
        sub.setObjectName("HeaderSubtitle")
        sub.setAlignment(Qt.AlignCenter)
        
        hl.addWidget(title)
        hl.addWidget(sub)
        hero.setLayout(hl)
        self.layout.addWidget(hero)
        
        # Description Card
        desc_box = QFrame()
        desc_box.setObjectName("Card")
        dl = QVBoxLayout()
        dl.setSpacing(8)
        dl.setContentsMargins(16, 12, 16, 12)
        
        desc = QLabel(
            "Plataforma de ingeniería para validación de linderos y colindancias.\n\n"
            "✨ Capacidades de Nueva Generación:\n"
            "• Contacto Topológico Puro (≤ 3cm) + Franja Ortogonal 2D\n"
            "• Orientación Notarial Centrada en el Observador\n"
            "• Inferencia y Suavizado por Colinealidad Angular (Deflexión ≤ 15°)\n"
            "• Monitoreo en Tiempo Real con Lupa Catastral\n"
            "• Dictamen Notarial Certificado con Verificación de Cierre"
        )
        desc.setWordWrap(True)
        desc.setAlignment(Qt.AlignCenter)
        desc.setStyleSheet("color: #cbd5e1; font-size: 9.5pt; line-height: 1.5;")
        dl.addWidget(desc)
        
        # Action Buttons (compact row)
        buttons_container = QWidget()
        buttons_layout = QHBoxLayout(buttons_container)
        buttons_layout.setSpacing(8)
        buttons_layout.setContentsMargins(0, 4, 0, 0)
        
        help_btn = QPushButton("📖 Documentación")
        help_btn.setCursor(Qt.PointingHandCursor)
        help_btn.clicked.connect(self.open_help)
        
        sim_btn = QPushButton("🔬 Simulador")
        sim_btn.setObjectName("ActionBtn")
        sim_btn.setCursor(Qt.PointingHandCursor)
        sim_btn.clicked.connect(self.open_simulator)

        dashboard_btn = QPushButton("🌐 Dashboard")
        dashboard_btn.setObjectName("GreenBtn")
        dashboard_btn.setCursor(Qt.PointingHandCursor)
        dashboard_btn.clicked.connect(self.open_dashboard)
        
        buttons_layout.addWidget(help_btn)
        buttons_layout.addWidget(sim_btn)
        buttons_layout.addWidget(dashboard_btn)
        dl.addWidget(buttons_container, 0, Qt.AlignCenter)
        
        desc_box.setLayout(dl)
        self.layout.addWidget(desc_box)
        self.layout.addStretch(1)
        
        attr = QLabel("Colindante Elite v3.0 • Ingeniería Catastral de Alta Precisión")
        attr.setObjectName("Attribution")
        attr.setAlignment(Qt.AlignRight | Qt.AlignBottom)
        self.layout.addWidget(attr)
    
    def open_help(self):
        try:
            from .simple_server import http_server
            webbrowser.open(http_server.url + "/")
        except:
            help_path = os.path.join(os.path.dirname(__file__), 'help', 'index.html')
            webbrowser.open('file://' + help_path)

    def open_simulator(self):
        sim_path = os.path.join(os.path.dirname(__file__), 'help', 'demo_comparador.html')
        if not os.path.exists(sim_path):
            sim_path = os.path.join(os.path.expanduser("~"), "demo_comparador_algoritmos.html")
        webbrowser.open('file://' + sim_path)
    
    def open_dashboard(self):
        try:
            from .simple_server import http_server
            webbrowser.open(http_server.get_url())
        except:
            dashboard_path = os.path.join(os.path.dirname(__file__), 'help', 'dashboard.html')
            webbrowser.open('file://' + dashboard_path)


# ──────────────────────────────────────────────────────────────────────────────
# PAGE 2: LAYERS
# ──────────────────────────────────────────────────────────────────────────────
class LayersPage(WizardPage):
    def __init__(self):
        super().__init__()
        self.add_title("Configuración de Capas de Análisis")
        container = QWidget()
        grid = QGridLayout()
        grid.setVerticalSpacing(10)
        grid.setHorizontalSpacing(12)
        
        self.cbo_lev = self.create_combo()
        self.cbo_terr = self.create_combo()
        self.cbo_vias = self.create_combo()
        self.cbo_pts = self.create_combo()
        self.cbo_spec = self.create_combo()
        
        self.add_row(grid, 0, "📐 Levantamiento (Polígono):", self.cbo_lev, "Capa del predio a analizar.")
        self.add_row(grid, 1, "🏘️ Terreno (Vecinos):", self.cbo_terr, "Capa de predios vecinos.")
        self.add_row(grid, 2, "🛤️ Malla Vial (Vías):", self.cbo_vias, "Capa opcional de vías públicas.")
        self.add_row(grid, 3, "🌊 Restricciones / Hidro:", self.cbo_spec, "Ríos, quebradas, canales.")
        self.add_row(grid, 4, "📍 Puntos / Vértices:", self.cbo_pts, "Capa de salida con linderos.")
        
        container.setLayout(grid)
        self.add_card(container)
        self.layout.addStretch(1)
        self.populate_layers()

    def create_combo(self): 
        c = QComboBox()
        c.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        return c

    def add_row(self, layout, row, label_text, widget, tooltip):
        lbl = QLabel(label_text)
        lbl.setToolTip(tooltip)
        lbl.setStyleSheet("font-weight: 600; color: #e2e8f0; font-size: 9.5pt;")
        layout.addWidget(lbl, row, 0)
        layout.addWidget(widget, row, 1)

    def populate_layers(self):
        layers = QgsProject.instance().mapLayers().values()
        valid_layers = [l for l in layers if isinstance(l, QgsVectorLayer)]
        for cbo in [self.cbo_lev, self.cbo_terr, self.cbo_vias, self.cbo_pts, self.cbo_spec]:
            cbo.clear()
            cbo.addItem("")
            for l in valid_layers: 
                cbo.addItem(l.name())
        
        self.set_sel(self.cbo_lev, "LEVANTAMIENTO")
        self.set_sel(self.cbo_terr, "Terreno")
        self.set_sel(self.cbo_vias, "vial")
        self.set_sel(self.cbo_pts, "COORDENADAS")
        self.set_sel(self.cbo_spec, "HIDRO")

    def set_sel(self, cbo, text):
        idx = cbo.findText(text, Qt.MatchContains)
        if idx >= 0: cbo.setCurrentIndex(idx)

    def validate(self):
        if self.cbo_lev.currentText() == self.cbo_terr.currentText() and self.cbo_lev.currentText() != "":
            QMessageBox.warning(self, "Conflicto de Capas", "Levantamiento y Terreno no pueden ser la misma capa.")
            return False
        if self.cbo_lev.currentText() == "" or self.cbo_pts.currentText() == "":
            QMessageBox.warning(self, "Capas Requeridas", "Las capas de Levantamiento y Puntos son obligatorias.")
            return False
        return True

    def get_config(self):
        return {
            'LEVANTAMIENTO': self.cbo_lev.currentText(),
            'TERRENO': self.cbo_terr.currentText(),
            'VIAS': self.cbo_vias.currentText(),
            'SPECIAL': self.cbo_spec.currentText(),
            'PUNTOS': self.cbo_pts.currentText()
        }


# ──────────────────────────────────────────────────────────────────────────────
# PAGE 3: FIELDS
# ──────────────────────────────────────────────────────────────────────────────
class FieldsPage(WizardPage):
    def __init__(self):
        super().__init__()
        self.add_title("Mapeo de Campos Catastrales")
        container = QWidget()
        grid = QGridLayout()
        grid.setVerticalSpacing(10)
        
        self.txt_cod_main = QLineEdit("CODIGO")
        self.txt_cod_vec = QLineEdit("codigo")
        self.txt_nodo = QLineEdit("NODO")
        self.txt_vert = QLineEdit("vertex_ind")
        
        self.add_field(grid, 0, "🔑 ID Predio Levantamiento:", self.txt_cod_main, "Campo identificador único en Levantamiento.")
        self.add_field(grid, 1, "🏷️ ID Predio Vecino:", self.txt_cod_vec, "Campo del código del vecino.")
        self.add_field(grid, 2, "🔗 Campo NODO:", self.txt_nodo, "Campo que asocia puntos con cada predio.")
        self.add_field(grid, 3, "📊 Índice de Vértice:", self.txt_vert, "Campo numérico de orden correlativo.")
        
        container.setLayout(grid)
        self.add_card(container)
        
        info = QLabel("💡 El motor de precisión aislará cada predio por su código de NODO.")
        info.setStyleSheet("color: #60a5fa; font-size: 8.5pt; margin-top: 6px; font-style: italic;")
        info.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(info)
        self.layout.addStretch(1)

    def add_field(self, layout, row, label, widget, tip):
        l = QLabel(label)
        l.setToolTip(tip)
        l.setStyleSheet("font-weight: 600; color: #e2e8f0; font-size: 9.5pt;")
        layout.addWidget(l, row, 0)
        layout.addWidget(widget, row, 1)

    def get_config(self):
        return {
            'PROTAGONISTA': self.txt_cod_main.text().strip(),
            'VECINO': self.txt_cod_vec.text().strip(),
            'NODO': self.txt_nodo.text().strip(),
            'VERTEX_INDEX': self.txt_vert.text().strip()
        }


# ──────────────────────────────────────────────────────────────────────────────
# PAGE 4: EXECUTION (Centro de Monitoreo Premium)
# ──────────────────────────────────────────────────────────────────────────────
class ExecutionPage(WizardPage):
    def __init__(self, wizard_ref=None):
        super().__init__()
        self.layout.setContentsMargins(12, 8, 12, 8)
        self.layout.setSpacing(6)
        self.wizard_ref = wizard_ref
        
        self.http_server = None
        self.status_manager = None
        self.latest_report_path = None
        self.current_seg_geom = None
        self._elapsed_seconds = 0
        self._timer = QTimer()
        self._timer.timeout.connect(self._tick_timer)
        
        # ═══ 1. STATUS BAR (compacta) ═══
        top_bar = QFrame()
        top_bar.setObjectName("Card")
        top_bar.setStyleSheet("""
            QFrame#Card { 
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #0c1629, stop:1 #0f172a); 
                border: 1px solid #1e293b; border-radius: 6px; 
            }
        """)
        top_layout = QHBoxLayout(top_bar)
        top_layout.setContentsMargins(10, 6, 10, 6)
        top_layout.setSpacing(12)
        
        self.lbl_status = QLabel("⏳ Listo para iniciar")
        self.lbl_status.setStyleSheet("font-size: 10pt; font-weight: 800; color: #60a5fa;")
        
        self.lbl_timer = QLabel("⏱ 00:00")
        self.lbl_timer.setStyleSheet("font-size: 9pt; font-family: monospace; color: #cbd5e1;")
        
        self.lbl_eta = QLabel("⏳ ETA: --:--")
        self.lbl_eta.setStyleSheet("font-size: 9pt; font-family: monospace; color: #94a3b8;")
        
        self.lbl_speed = QLabel("🚀 0.0 tr/s")
        self.lbl_speed.setStyleSheet("font-size: 9pt; font-family: monospace; color: #34d399;")
        
        # Progress percentage label
        self.lbl_percent = QLabel("0%")
        self.lbl_percent.setStyleSheet("font-size: 10pt; font-weight: 800; color: #2563eb; font-family: monospace;")
        
        top_layout.addWidget(self.lbl_status)
        top_layout.addStretch()
        top_layout.addWidget(self.lbl_timer)
        top_layout.addWidget(self.lbl_eta)
        top_layout.addWidget(self.lbl_speed)
        top_layout.addWidget(self.lbl_percent)
        
        self.layout.addWidget(top_bar)
        
        # ═══ 2. PROGRESS BAR ═══
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(6)
        self.layout.addWidget(self.progress_bar)
        
        # ═══ 3. MAIN SPLITTER: LUPA + LOGS | MAPA ═══
        splitter = QSplitter(Qt.Horizontal)
        splitter.setHandleWidth(3)
        splitter.setStyleSheet("QSplitter::handle { background: #1e293b; }")
        
        # LEFT PANEL
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(6)
        
        # LUPA CATASTRAL (compacta)
        lupa_box = QGroupBox("🔍 LUPA CATASTRAL EN VIVO")
        lupa_box.setStyleSheet("""
            QGroupBox { 
                background: #0c1424; border: 1px solid rgba(37, 99, 235, 0.3); 
                border-radius: 6px; font-weight: 800; font-size: 9pt;
            }
        """)
        lupa_layout = QGridLayout()
        lupa_layout.setContentsMargins(10, 14, 10, 8)
        lupa_layout.setVerticalSpacing(4)
        lupa_layout.setHorizontalSpacing(8)
        
        lbl_style = "font-size: 8.5pt; color: #64748b; font-weight: 600;"
        
        self.val_tramo = QLabel("Esperando...")
        self.val_tramo.setStyleSheet("font-family: monospace; font-size: 10pt; font-weight: 800; color: #60a5fa;")
        
        self.val_dist = QLabel("0.00 m")
        self.val_dist.setStyleSheet("font-family: monospace; font-size: 9.5pt; font-weight: 700; color: #ffffff;")
        
        self.val_colindante = QLabel("-")
        self.val_colindante.setStyleSheet("font-size: 9.5pt; font-weight: 800; color: #f8fafc;")
        
        self.val_metodo = QLabel("-")
        self.val_metodo.setStyleSheet("font-size: 8.5pt; font-weight: 600; color: #34d399;")
        
        self.val_conf = QLabel("-")
        self.val_conf.setStyleSheet("font-size: 8.5pt; font-weight: 700; color: #3b82f6;")
        
        labels_data = [
            ("Tramo:", self.val_tramo),
            ("Longitud:", self.val_dist),
            ("Colindante:", self.val_colindante),
            ("Método:", self.val_metodo),
            ("Fiabilidad:", self.val_conf),
        ]
        for row, (label_text, val_widget) in enumerate(labels_data):
            lbl = QLabel(label_text)
            lbl.setStyleSheet(lbl_style)
            lupa_layout.addWidget(lbl, row, 0)
            lupa_layout.addWidget(val_widget, row, 1)
        
        lupa_box.setLayout(lupa_layout)
        left_layout.addWidget(lupa_box)
        
        # CONTROLS ROW
        ctrl_card = QFrame()
        ctrl_card.setObjectName("Card")
        ctrl_layout = QHBoxLayout(ctrl_card)
        ctrl_layout.setContentsMargins(8, 5, 8, 5)
        ctrl_layout.setSpacing(6)
        
        self.chk_lupa = QCheckBox("Auto-Zoom")
        self.chk_lupa.setChecked(True)
        self.chk_lupa.setStyleSheet("font-size: 8.5pt;")
        
        self.btn_pause = QPushButton("⏸ Pausar")
        self.btn_pause.setCursor(Qt.PointingHandCursor)
        self.btn_pause.setFixedHeight(26)
        
        self.btn_step = QPushButton("⏭ Paso")
        self.btn_step.setCursor(Qt.PointingHandCursor)
        self.btn_step.setEnabled(False)
        self.btn_step.setFixedHeight(26)
        
        self.cbo_speed = QComboBox()
        self.cbo_speed.addItem("⚡ Rápido", 0)
        self.cbo_speed.addItem("⏱ Normal", 150)
        self.cbo_speed.addItem("🔍 Detalle", 500)
        self.cbo_speed.setCurrentIndex(1)
        self.cbo_speed.setFixedHeight(26)
        
        ctrl_layout.addWidget(self.chk_lupa)
        ctrl_layout.addStretch()
        ctrl_layout.addWidget(self.btn_pause)
        ctrl_layout.addWidget(self.btn_step)
        ctrl_layout.addWidget(self.cbo_speed)
        
        left_layout.addWidget(ctrl_card)
        
        # LOG TERMINAL
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setMinimumHeight(60)
        left_layout.addWidget(self.log_text, 1)
        
        # RIGHT PANEL: MAP
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)
        
        map_header = QLabel("  📍 Vista Geográfica en Vivo")
        map_header.setStyleSheet("""
            background: #0c1424; color: #60a5fa; font-weight: 700; 
            font-size: 8.5pt; padding: 4px 8px; 
            border: 1px solid #1e293b; border-bottom: none; border-radius: 6px 6px 0 0;
        """)
        right_layout.addWidget(map_header)
        
        self.canvas = QgsMapCanvas()
        self.canvas.setCanvasColor(QColor("#060911"))
        self.canvas.enableAntiAliasing(True)
        self.canvas.setMinimumHeight(100)
        self.canvas.setStyleSheet("border: 1px solid #1e293b; border-radius: 0 0 6px 6px;")
        right_layout.addWidget(self.canvas, 1)
        
        splitter.addWidget(left_panel)
        splitter.addWidget(right_panel)
        splitter.setStretchFactor(0, 45)
        splitter.setStretchFactor(1, 55)
        splitter.setSizes([320, 400])
        
        self.layout.addWidget(splitter, 1)
        
        # ═══ 4. BOTTOM ACTION BAR ═══
        btn_bar = QHBoxLayout()
        btn_bar.setSpacing(8)
        btn_bar.setContentsMargins(0, 4, 0, 0)
        
        self.btn_report = QPushButton("📄 Ver Dictamen Notarial")
        self.btn_report.setObjectName("ActionBtn")
        self.btn_report.setEnabled(False)
        self.btn_report.setCursor(Qt.PointingHandCursor)
        self.btn_report.clicked.connect(self.open_report)
        
        self.btn_dashboard = QPushButton("🌐 Dashboard 3D")
        self.btn_dashboard.setEnabled(False)
        self.btn_dashboard.setCursor(Qt.PointingHandCursor)
        self.btn_dashboard.clicked.connect(self.open_dashboard)
        
        self.btn_stop = QPushButton("🛑 Detener")
        self.btn_stop.setObjectName("DestructiveBtn")
        self.btn_stop.setCursor(Qt.PointingHandCursor)
        self.btn_stop.clicked.connect(self.stop_process)
        
        btn_bar.addWidget(self.btn_report)
        btn_bar.addWidget(self.btn_dashboard)
        btn_bar.addStretch()
        btn_bar.addWidget(self.btn_stop)
        
        self.layout.addLayout(btn_bar)
        
        # RubberBands para visualización
        self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rubber_band.setColor(QColor("#3b82f6"))
        self.rubber_band.setWidth(3)

    def _tick_timer(self):
        """Timer interno para el cronómetro visual"""
        self._elapsed_seconds += 1
        m, s = divmod(self._elapsed_seconds, 60)
        h, m = divmod(m, 60)
        if h > 0:
            self.lbl_timer.setText(f"⏱ {h:02d}:{m:02d}:{s:02d}")
        else:
            self.lbl_timer.setText(f"⏱ {m:02d}:{s:02d}")

    def initialize(self):
        if not self.wizard_ref: return
        self.status_manager = self.wizard_ref.status_manager
        self.http_server = self.wizard_ref.http_server
        self.btn_dashboard.setEnabled(True)
        self._elapsed_seconds = 0
        self._timer.start(1000)
        self.log("🚀 Motor de análisis listo. Configurando capas...", "#60a5fa")

    def on_step_inspected(self, data):
        """Actualiza la Lupa Catastral con los datos en tiempo real de cada tramo"""
        step = data.get('step', 0)
        total = data.get('total_steps', 0)
        self.val_tramo.setText(f"{data.get('tramo_label')} ({step}/{total})")
        self.val_dist.setText(f"{data.get('distancia', 0.0):.2f} m  [{data.get('cardinal', '-')}]")
        self.val_colindante.setText(f"{data.get('colindante', '-')}")
        self.val_metodo.setText(f"{data.get('metodo', '-')}")
        self.val_conf.setText(f"{data.get('confianza', '-')}")
        
        # Si el modo lupa está activo, hacer zoom centrado al tramo
        geom = data.get('geom')
        if geom and self.chk_lupa.isChecked():
            try:
                extent = geom.boundingBox()
                extent.scale(2.2)
                self.canvas.setExtent(extent)
                self.canvas.refresh()
            except:
                pass
        
        self.log(f"Tramo {data.get('tramo_label')} ({data.get('distancia')}m): {data.get('colindante')} [{data.get('confianza')}]")
        QApplication.processEvents()

    def on_stats_updated(self, stats):
        self.lbl_timer.setText(f"⏱ {stats.get('elapsed_str', '00:00')}")
        self.lbl_eta.setText(f"⏳ ETA: {stats.get('eta_str', '--:--')}")
        self.lbl_speed.setText(f"🚀 {stats.get('speed', 0.0)} tr/s")
        QApplication.processEvents()

    def highlight_geometry(self, geometry):
        try:
            self.rubber_band.reset(QgsWkbTypes.LineGeometry)
            self.rubber_band.addGeometry(geometry, None)
            self.rubber_band.updatePosition()
            self.rubber_band.show()
        except:
            pass

    def update_progress(self, val, msg):
        if val >= 0: 
            self.progress_bar.setValue(val)
            self.lbl_percent.setText(f"{val}%")
        self.lbl_status.setText(f"⚙️ {msg}")
        
        if val == 100:
            self._timer.stop()
            self.lbl_status.setText("✅ PROCESO COMPLETADO CON ÉXITO")
            self.lbl_status.setStyleSheet("font-size: 10pt; font-weight: 800; color: #10b981;")
            self.lbl_percent.setStyleSheet("font-size: 10pt; font-weight: 800; color: #10b981; font-family: monospace;")
            self.btn_stop.setEnabled(False)
            self.btn_report.setEnabled(True)
            self.btn_dashboard.setEnabled(True)
        elif val == -1:
            self._timer.stop()
            self.lbl_status.setText("❌ INCONSISTENCIA / ERROR")
            self.lbl_status.setStyleSheet("font-size: 10pt; font-weight: 800; color: #f43f5e;")
            self.log(f"ALERTA: {msg}", "#f43f5e")

    def open_dashboard(self):
        try:
            from .simple_server import http_server
            webbrowser.open(http_server.get_url())
        except:
            webbrowser.open("http://127.0.0.1:8000/dashboard")

    def open_report(self):
        if self.latest_report_path and os.path.exists(self.latest_report_path):
            webbrowser.open('file://' + self.latest_report_path)
        else:
            try:
                from .simple_server import http_server
                webbrowser.open(http_server.get_report_url())
            except:
                pass

    def stop_process(self):
        self._timer.stop()
        self.log("Detención solicitada por el usuario...", "#f43f5e")
        if self.wizard_ref and hasattr(self.wizard_ref, 'engine') and self.wizard_ref.engine:
            self.wizard_ref.engine.stop_requested = True
        self.lbl_status.setText("🛑 PROCESO DETENIDO")

    def log(self, msg, color="#34d399"):
        self.log_text.append(f'<span style="color:{color}">▸ {msg}</span>')
        sb = self.log_text.verticalScrollBar()
        sb.setValue(sb.maximum())


# ──────────────────────────────────────────────────────────────────────────────
# MAIN WIZARD DIALOG (Premium, Compacto, Redimensionable)
# ──────────────────────────────────────────────────────────────────────────────
class EliteWizard(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("EliteWizardDialog")
        self.setWindowTitle("Colindante Elite • Certificación Territorial de Alta Precisión")
        
        # ═══ TAMAÑO ADAPTATIVO Y REDIMENSIONABLE ═══
        self.setMinimumSize(520, 380)
        self.resize(720, 540)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        # Permitir redimensionar libremente (ya es default para QDialog pero lo explicitamos)
        self.setWindowFlags(self.windowFlags() | Qt.WindowMinMaxButtonsHint)
        
        self.setStyleSheet(STYLESHEET)
        
        self.status_manager = None
        self.http_server = None
        self.engine = None
        
        # Iniciar Servidor HTTP + StatusManager
        try:
            from .status_manager import status_manager
            from .simple_server import http_server
            self.status_manager = status_manager
            self.http_server = http_server
            http_server.start(status_manager)
            status_manager.add_log("Servidor local iniciado", "info")
        except Exception as e:
            pass
        
        # ═══ LAYOUT PRINCIPAL ═══
        self.main_layout = QVBoxLayout()
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)
        
        # STEP INDICATOR (barra de progreso visual)
        self.step_indicator = StepIndicator()
        self.main_layout.addWidget(self.step_indicator)
        
        # STACKED PAGES
        self.stack = QStackedWidget()
        self.stack.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.page_welcome = WelcomePage()
        self.page_layers = LayersPage()
        self.page_fields = FieldsPage()
        self.page_exec = ExecutionPage(wizard_ref=self)
        
        self.stack.addWidget(self.page_welcome)
        self.stack.addWidget(self.page_layers)
        self.stack.addWidget(self.page_fields)
        self.stack.addWidget(self.page_exec)
        self.main_layout.addWidget(self.stack, 1)
        
        # ═══ NAVIGATION BAR (Siempre visible, compacta) ═══
        self.nav_bar = QFrame()
        self.nav_bar.setObjectName("NavBar")
        self.nav_bar.setFixedHeight(48)
        nav_layout = QHBoxLayout()
        nav_layout.setContentsMargins(16, 8, 16, 8)
        nav_layout.setSpacing(10)
        
        self.btn_cancel = QPushButton("✕ CANCELAR")
        self.btn_cancel.setObjectName("DestructiveBtn")
        self.btn_cancel.setCursor(Qt.PointingHandCursor)
        self.btn_cancel.clicked.connect(self.close)
        self.btn_cancel.setFixedHeight(30)
        
        self.btn_back = QPushButton("◀ ANTERIOR")
        self.btn_back.setCursor(Qt.PointingHandCursor)
        self.btn_back.clicked.connect(self.go_back)
        self.btn_back.setFixedHeight(30)
        self.btn_back.hide()
        
        self.btn_next = QPushButton("COMENZAR ▶")
        self.btn_next.setObjectName("PrimaryBtn")
        self.btn_next.setCursor(Qt.PointingHandCursor)
        self.btn_next.clicked.connect(self.go_next)
        self.btn_next.setFixedHeight(30)
        self.btn_next.setMinimumWidth(140)
        
        nav_layout.addWidget(self.btn_cancel)
        nav_layout.addStretch()
        nav_layout.addWidget(self.btn_back)
        nav_layout.addWidget(self.btn_next)
        
        self.nav_bar.setLayout(nav_layout)
        self.main_layout.addWidget(self.nav_bar)
        self.setLayout(self.main_layout)
        
        self.current_step = 0

    def go_next(self):
        if self.current_step == 0:
            self.current_step = 1
            self.stack.setCurrentIndex(1)
            self.step_indicator.set_step(1)
            self.btn_back.show()
            self.btn_next.setText("CAMPOS ▶")
        elif self.current_step == 1:
            if self.page_layers.validate():
                self.current_step = 2
                self.stack.setCurrentIndex(2)
                self.step_indicator.set_step(2)
                self.btn_next.setText("⚡ INICIAR")
        elif self.current_step == 2:
            self.current_step = 3
            self.stack.setCurrentIndex(3)
            self.step_indicator.set_step(3)
            self.nav_bar.hide()
            self.page_exec.initialize()
            
            # Configurar canvas con las capas del proyecto
            self.page_exec.canvas.setDestinationCrs(QgsProject.instance().crs())
            self.page_exec.canvas.setLayers(QgsProject.instance().mapLayers().values())
            self.page_exec.canvas.refresh()
            
            # Lanzar ejecución
            QTimer.singleShot(400, self.run_process)

    def go_back(self):
        if self.current_step > 0:
            self.current_step -= 1
            self.stack.setCurrentIndex(self.current_step)
            self.step_indicator.set_step(self.current_step)
        if self.current_step == 0:
            self.btn_back.hide()
            self.btn_next.setText("COMENZAR ▶")
        elif self.current_step == 1:
            self.btn_next.setText("CAMPOS ▶")

    def toggle_pause(self):
        if not self.engine: return
        new_state = not self.engine.is_paused
        self.engine.set_paused(new_state)
        if new_state:
            self.page_exec.btn_pause.setText("▶ Reanudar")
            self.page_exec.btn_step.setEnabled(True)
            self.page_exec.lbl_status.setText("⏸ En Pausa (Inspección Paso a Paso)")
        else:
            self.page_exec.btn_pause.setText("⏸ Pausar")
            self.page_exec.btn_step.setEnabled(False)
            self.page_exec.lbl_status.setText("⚙️ Procesando...")

    def on_speed_changed(self):
        if not self.engine: return
        ms = self.page_exec.cbo_speed.currentData()
        self.engine.set_delay(ms)

    def run_process(self):
        config = {
            'LAYERS': self.page_layers.get_config(), 
            'FIELDS': self.page_fields.get_config()
        }
        try:
            self.engine = AICore(config)
            self.engine.set_delay(self.page_exec.cbo_speed.currentData())
            
            # Conexión de señales
            self.engine.progress_changed.connect(self.page_exec.update_progress)
            self.engine.visual_feedback.connect(self.page_exec.highlight_geometry)
            self.engine.step_inspected.connect(self.page_exec.on_step_inspected)
            self.engine.stats_updated.connect(self.page_exec.on_stats_updated)
            self.engine.finished.connect(self.on_finish)
            
            # Conexión de controles de reproducción
            self.page_exec.btn_pause.clicked.connect(self.toggle_pause)
            self.page_exec.btn_step.clicked.connect(self.engine.step_advance)
            self.page_exec.cbo_speed.currentIndexChanged.connect(self.on_speed_changed)
            
            self.engine.run()
        except Exception as e:
            self.page_exec.update_progress(-1, str(e))
            self.nav_bar.show()

    def on_finish(self, success, msg):
        self.nav_bar.show()
        self.btn_back.hide()
        self.btn_cancel.hide()
        self.btn_next.setText("FINALIZAR ✓")
        self.btn_next.clicked.disconnect()
        self.btn_next.clicked.connect(self.accept)
        
        # Recuperar ruta de reporte
        if self.engine and self.engine.reports:
            output_dir = QgsProject.instance().homePath() if QgsProject.instance().homePath() else os.path.expanduser("~")
            rep_path = os.path.join(output_dir, "reporte_notarial_colindantes.html")
            self.page_exec.latest_report_path = rep_path
            if self.http_server:
                self.http_server.set_latest_report(rep_path)
            self.page_exec.btn_report.setEnabled(True)
            
        if success:
            self.page_exec.update_progress(100, msg)
        else:
            self.page_exec.update_progress(-1, msg)
