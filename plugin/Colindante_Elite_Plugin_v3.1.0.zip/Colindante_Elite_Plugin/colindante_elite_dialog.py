import os
from qgis.PyQt import uic
from qgis.PyQt import QtWidgets

# This loads the .ui file so that PyQt can use it
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'colindante_elite_dialog_base.ui'))

class ColindanteEliteDialog(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        """Constructor."""
        super(ColindanteEliteDialog, self).__init__(parent)
        # Set up the user interface from Designer manually defined .ui file
        self.setupUi(self)
        
        # Load custom style for professional aesthetic
        self.load_style()

    def load_style(self):
        """Loads the QSS stylesheet."""
        style_path = os.path.join(os.path.dirname(__file__), 'style.qss')
        if os.path.exists(style_path):
            with open(style_path, 'r') as f:
                self.setStyleSheet(f.read())
