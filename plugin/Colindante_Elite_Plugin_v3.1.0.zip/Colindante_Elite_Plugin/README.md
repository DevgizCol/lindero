# 🚀 Colindante Elite Plugin (God Mode Edition)

> **La Plataforma Definitiva de Inteligencia Territorial para QGIS.**
> Arquitectura de Microservicios | Visualización 3D WebGL | IA Generativa Local

![Version](https://img.shields.io/badge/version-3.0.0-blue.svg)
![QGIS](https://img.shields.io/badge/QGIS-3.34+-green.svg)
![Stack](https://img.shields.io/badge/Stack-FastAPI%20%7C%20React%20%7C%20PostGIS-purple.svg)

## 🌟 ¿Qué es Colindante Elite?

Colindante Elite v3.0 no es solo un plugin; es una **plataforma de ingeniería completa** que se ejecuta dentro de QGIS. Transforma el análisis catastral tradicional en una experiencia "God Mode" mediante:

1.  **Frontend de Nueva Generación**: Una SPA (Single Page Application) construida con **React, Vite y Tailwind CSS**, que reemplaza las interfaces estáticas de QGIS.
2.  **Visualización 3D Masiva**: Motor **Deck.gl** capaz de renderizar millones de geometrías con aceleración GPU.
3.  **Backend Enterprise**: Microservicios **FastAPI** orquestados con Docker, respaldados por **PostGIS** y **Redis**.
4.  **Automatización "Zero-Click"**: El plugin gestiona su propia infraestructura. Al abrirlo, levanta los contenedores necesarios automáticamente.

---

## 🏗️ Arquitectura Híbrida

El sistema utiliza un **Smart Proxy** (`simple_server.py`) que actúa como puente:

*   **Modo Enterprise (Recomendado)**: Si Docker está disponible, el plugin delega el procesamiento pesado a un clúster de contenedores (FastAPI + PostGIS).
*   **Modo Standalone (Fallback)**: Si no hay Docker, el plugin funciona localmente usando SQLite y procesamiento en hilo principal, asegurando que nunca deje de funcionar.

---

## 🚀 Instalación y Despliegue

### Requisitos Previos
*   QGIS 3.34 o superior.
*   Docker & Docker Compose (Opcional, para Modo Enterprise).
*   Node.js 18+ (Solo para desarrollo del frontend).

### 1. Instalación Rápida (Usuario Final)
Simplemente copia la carpeta del plugin a tu directorio de QGIS:

```bash
# Linux
cp -r Colindante_Elite_Plugin ~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/

# Windows
xcopy Colindante_Elite_Plugin %APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\ /E /I
```

### 2. Desarrollo (Modo Dios)

Si vas a modificar el código, usa el script de despliegue automático:

```bash
./deploy.sh
```

### 3. Compilación del Frontend (React)

Si modificas la interfaz en `frontend/`, debes recompilar:

```bash
cd frontend
npm install
npm run build
```
*Esto generará los archivos optimizados en `help/dist/`, listos para ser servidos por Python.*

---

## 🛠️ Comandos de Infraestructura

El plugin intenta levantar Docker automáticamente, pero puedes controlarlo manualmente:

```bash
# Levantar Backend y Base de Datos
docker-compose up -d

# Ver logs del sistema
docker-compose logs -f

# Reiniciar servicios
docker-compose restart
```

## 🧠 Estructura del Proyecto

```
Colindante_Elite_Plugin/
├── backend/                # Microservicios Python (FastAPI)
│   ├── app/                # Código de la API
│   └── Dockerfile          # Definición del contenedor
├── frontend/               # Interfaz de Usuario (React + Vite)
│   ├── src/                # Componentes React
│   └── vite.config.js      # Configuración de Build
├── help/                   # Archivos estáticos servidos
│   └── dist/               # Build final del Frontend (Generado)
├── docker-compose.yml      # Orquestación de infraestructura
├── colindante_elite.py     # Punto de entrada QGIS
├── simple_server.py        # Smart Proxy & Web Server
├── db_connector.py         # Capa de persistencia híbrida
└── infra_manager.py        # Gestor de procesos (Auto-Start)
```

---

## 🤝 Contribución

El proyecto sigue la metodología **"Zero Margin for Error"**.
*   Todo código nuevo debe pasar por `ruff` (linting).
*   Las nuevas features deben tener tests en `tests/`.
*   La documentación debe actualizarse con cada cambio mayor.

---

**Desarrollado con ❤️ e IA por el equipo de Colindante Elite.**
