# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from qgis.core import QgsMessageLog, Qgis

from .resources import *
from .wizard import EliteWizard
import os.path
import sys

# Importación Robusta del Infra Manager
infra = None
try:
    # Intentar importación relativa estándar
    from .infra_manager import infra
except ImportError:
    try:
        # Fallback: Agregar directorio actual al path e importar directamente
        sys.path.append(os.path.dirname(__file__))
        import infra_manager
        infra = infra_manager.infra
    except Exception as e:
        QgsMessageLog.logMessage(f"Error cargando InfraManager: {e}", 'Colindante Elite', Qgis.Warning)

class ColindanteElite:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'ColindanteElite_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        self.actions = []
        self.menu = '&Colindante Elite'

    def add_action(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)
        if status_tip: action.setStatusTip(status_tip)
        if whats_this: action.setWhatsThis(whats_this)
        if add_to_toolbar: self.iface.addToolBarIcon(action)
        if add_to_menu: self.iface.addPluginToMenu(self.menu, action)
        self.actions.append(action)
        return action

    def initGui(self):
        icon_path = ':/plugins/Colindante_Elite_Plugin/icon.png'
        self.add_action(
            icon_path,
            text='Colindante Elite (God Mode)',
            callback=self.run,
            parent=self.iface.mainWindow())

    def unload(self):
        # Detener infraestructura al cerrar (si se cargó correctamente)
        if infra:
            try:
                infra.stop_engines()
            except:
                pass
        
        for action in self.actions:
            self.iface.removePluginMenu('&Colindante Elite', action)
            self.iface.removeToolBarIcon(action)

    def run(self):
        """Lanza el Asistente Elite (God Mode)."""
        
        # 1. Auto-Start Magic: Iniciar infraestructura en background
        if infra:
            self.iface.messageBar().pushMessage("Colindante Elite", "Iniciando Motores Enterprise (Docker + AI)...", level=0, duration=3)
            try:
                infra.start_engines()
            except Exception as e:
                QgsMessageLog.logMessage(f"Error iniciando motores: {e}", 'Colindante Elite', Qgis.Warning)
        else:
            self.iface.messageBar().pushMessage("Colindante Elite", "Modo Local (Infraestructura no disponible)", level=1, duration=3)
        
        # 2. Abrir Interfaz
        try:
            self.dlg = EliteWizard(self.iface.mainWindow())
            self.dlg.show()
            self.dlg.exec_()
        except Exception as e:
            self.iface.messageBar().pushMessage("Error", f"No se pudo abrir el asistente: {e}", level=2)
            import traceback
            QgsMessageLog.logMessage(traceback.format_exc(), 'Colindante Elite', Qgis.Critical)
