# -*- coding: utf-8 -*-
import math
import statistics
import traceback
import re
import datetime
import os
import time
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsField, QgsFeature, QgsGeometry,
    QgsPointXY, QgsSpatialIndex, QgsMarkerSymbol, QgsFeatureRequest
)
from qgis.PyQt.QtCore import QObject, pyqtSignal, QMetaType
from qgis.PyQt.QtWidgets import QApplication

# Importar módulos empresariales
try:
    from .logger import logger
    from .config_manager import config
    from .export_manager import ExportManager
    from .history_manager import history
    from .ml_predictor import predictor
    from .db_connector import db_connector
except ImportError:
    # Fallback si no están disponibles
    class DummyLogger:
        def debug(self, *args, **kwargs): pass
        def info(self, *args, **kwargs): pass
        def warning(self, *args, **kwargs): pass
        def error(self, *args, **kwargs): pass
        def log_analysis(self, *args, **kwargs): pass
    logger = DummyLogger()
    config = None
    ExportManager = None
    history = None
    predictor = None
    db_connector = None

from qgis.core import QgsRectangle

try:
    import shapely
    from .motor_colindantes import (Contexto, Lote, Parametros, analizar_lote, nivel_conf, VIA)
    MOTOR_OK = True
except Exception as _e:      # shapely viene con QGIS; si faltara, se avisa al ejecutar
    MOTOR_OK = False
    MOTOR_ERROR = str(_e)

class NarrativeEngine:
    """Motor de Generación de Lenguaje Natural Jurídico (Hybrid: Rule-Based + LLM Ready)."""
    
    @staticmethod
    def clean_name(text):
        if not text: return "DESCONOCIDO"
        t = str(text).upper().strip()
        replacements = {
            r'\bCL\b': 'CALLE', r'\bCLL\b': 'CALLE', r'\bKR\b': 'CARRERA', 
            r'\bKRA\b': 'CARRERA', r'\bCR\b': 'CARRERA', r'\bDG\b': 'DIAGONAL',
            r'\bTV\b': 'TRANSVERSAL', r'\bAV\b': 'AVENIDA', r'\bQ\.\b': 'QUEBRADA '
        }
        for pattern, repl in replacements.items():
            t = re.sub(pattern, repl, t)
        return t

    @staticmethod
    def generate_legal_text(seg, use_llm=False):
        """
        Genera la descripción técnica.
        Args:
            seg (dict): Datos del segmento.
            use_llm (bool): Si es True, simula una llamada a IA para redacción avanzada.
        """
        ori = seg['orientacion'].upper()
        card = seg['cardinal']
        vec = NarrativeEngine.clean_name(seg['colindante'])
        dist = f"{seg['length']:.2f}".replace('.', ',')
        
        if use_llm:
            # AQUÍ SE CONECTARÍA CON OPENAI / OLLAMA
            # Prompt simulado: "Redacta como notario experto: tramo {ori}, {dist}m, vecino {vec}"
            variations = [
                f"Colinda por el {ori}, en una longitud de {dist} metros, con el predio de {vec}.",
                f"Por el {ori}, partiendo del vértice anterior, en trazo de {dist} metros lindando con {vec}.",
                f"En dirección {card} ({ori}), mide {dist} metros y colinda con {vec}."
            ]
            # Por ahora retornamos una variación determinista basada en la longitud para dar variedad
            return variations[int(seg['length']) % 3]
            
        return f"Por el costado {ori} ({card}), en una extensión de {dist} metros, colinda con {vec}."

class AICore(QObject):
    """
    Motor de Inteligencia Espacial 'GOD MODE' con Precisión Milimétrica.
    """
    progress_changed = pyqtSignal(int, str)
    visual_feedback = pyqtSignal(object)   # Emite QgsGeometry
    step_inspected = pyqtSignal(dict)      # Emite datos para la LUPA en vivo
    stats_updated = pyqtSignal(dict)       # Emite métricas de tiempo, velocidad y ETA
    finished = pyqtSignal(bool, str)

    def __init__(self, config):
        super().__init__()
        self.config = config
        self.proj = QgsProject.instance()
        self.stop_requested = False
        self.is_paused = False
        self.step_trigger = False
        self.delay_ms = 0
        self.anomaly_detector = ForensicValidator()
        self.error_layer = None
        self.reports = []

    def set_paused(self, val):
        self.is_paused = val

    def step_advance(self):
        self.step_trigger = True

    def set_delay(self, ms):
        self.delay_ms = ms

    def setup_error_layer(self):
        lname = "Colindante_Elite_Diagnostico"
        old = self.proj.mapLayersByName(lname)
        if old: self.proj.removeMapLayers([l.id() for l in old])
        
        self.error_layer = QgsVectorLayer("Point?crs=" + self.proj.crs().authid(), lname, "memory")
        pr = self.error_layer.dataProvider()
        pr.addAttributes([
            QgsField("CAUSA", QMetaType.Type.QString),
            QgsField("DISTANCIA", QMetaType.Type.Double),
            QgsField("ACCION", QMetaType.Type.QString)
        ])
        self.error_layer.updateFields()
        
        symbol = QgsMarkerSymbol.createSimple({'color': '#e74c3c', 'size': '4', 'outline_color': 'white'})
        self.error_layer.renderer().setSymbol(symbol)
        self.proj.addMapLayer(self.error_layer)

    def log_error(self, point, cause, dist, action):
        if not self.error_layer: return
        f = QgsFeature()
        f.setGeometry(QgsGeometry.fromPointXY(point))
        f.setAttributes([cause, dist, action])
        self.error_layer.dataProvider().addFeature(f)

    def run(self):
        start_time = time.time()
        logger.info("Iniciando análisis de colindantes", event_type='analysis_start')
        
        # Inicializar StatusManager
        try:
            from .status_manager import status_manager
            status_manager.start_analysis()
        except:
            status_manager = None
        
        try:
            self.setup_error_layer()
            
            # 1. Carga de Capas
            logger.debug("Cargando capas del proyecto")
            layers = {}
            for k, v in self.config['LAYERS'].items():
                if not v: continue
                l = self.proj.mapLayersByName(v)
                if l: 
                    layers[k] = l[0]
                    logger.debug(f"Capa cargada: {k} = {v}")
            
            # 2. Preparar Campos
            l_pts = layers['PUNTOS']
            self.prepare_fields(l_pts)
            
            # 3. Índices
            logger.debug("Construyendo índices espaciales")
            indices = {
                'TERRENO': QgsSpatialIndex(layers['TERRENO'].getFeatures()),
                'PUNTOS': QgsSpatialIndex(l_pts.getFeatures())
            }
            if 'VIAS' in layers: indices['VIAS'] = QgsSpatialIndex(layers['VIAS'].getFeatures())
            if 'SPECIAL' in layers: indices['SPECIAL'] = QgsSpatialIndex(layers['SPECIAL'].getFeatures())

            # 4. Procesamiento
            selection = layers['LEVANTAMIENTO'].selectedFeatures()
            if not selection: 
                logger.error("No hay predios seleccionados")
                raise Exception("Debe seleccionar el predio a analizar.")
            
            logger.info(f"Procesando {len(selection)} predio(s) seleccionado(s)")
            
            # Contexto del motor de colindantes: predios y vías alrededor de la selección, y TODOS los
            # lotes del levantamiento (el vecino de un lote suele ser otro lote levantado)
            if not MOTOR_OK:
                raise Exception("No se pudo cargar el motor de colindantes: " + MOTOR_ERROR)
            ctx = self._contexto_motor(layers, selection)

            l_pts.startEditing()
            total = len(selection)
            pts_map = {p.id(): p for p in l_pts.getFeatures()}
            failures = 0
            self.reports = []
            segments_count = 0
            processed_geometries = []  # Acumular geometrías para el dashboard
            
            # Estimar total de tramos para cálculo de ETA
            total_segments_expected = 0
            for sf in selection:
                sg = sf.geometry()
                if sg and sg.isGeosValid():
                    sv = list(sg.vertices())
                    total_segments_expected += max(1, len(sv) - 1)
            if total_segments_expected == 0: total_segments_expected = total * 4

            if status_manager:
                status_manager.start_analysis(total_predios=total)

            for i, feat in enumerate(selection):
                if self.stop_requested: break
                try:
                    progress = int((i/total)*100)
                    feat_id = feat.id()
                    
                    # 1. Obtener datos clave del Predio Protagonista
                    try:
                        code_main = str(feat.attribute(self.config['FIELDS']['PROTAGONISTA'])) # Ej: "010203"
                        nodo_val = str(feat.attribute(self.config['FIELDS']['NODO']))         # Ej: "12"
                    except KeyError:
                        self.log_error(QgsPointXY(0,0), "ERROR_CAMPOS", 0, "Faltan campos CODIGO o NODO en Levantamiento")
                        continue

                    task_msg = f"Analizando Predio {i+1}/{total} (ID: {code_main} | NODO: {nodo_val})..."
                    self.progress_changed.emit(progress, task_msg)
                    
                    geom = feat.geometry()
                    if not geom.isGeosValid(): geom = geom.makeValid()
                    geom.forceRHR()
                    
                    if geom.isEmpty():
                        self.log_error(QgsPointXY(0,0), "GEOMETRIA_NULA", 0, "Revisar dibujo")
                        failures += 1
                        continue
                    
                    # Acumular para dashboard
                    processed_geometries.append({
                        'id': code_main,
                        'geometry': geom,
                        'area': geom.area(),
                        'perimeter': geom.length()
                    })
                    if status_manager:
                        self._send_geometries_to_dashboard(status_manager, processed_geometries)

                    # PREDICCIÓN DE CALIDAD (ML/Heurística)
                    if predictor:
                        score, risk, reasons = predictor.predict(geom)
                        if risk == "ALTO":
                            self.log_error(geom.centroid().asPoint(), "CALIDAD_BAJA", 0, 
                                         f"Riesgo Alto ({score}/100): {', '.join(reasons)}")
                            if score < 20:
                                failures += 1
                                continue
                        elif risk == "MEDIO":
                            logger.warning(f"Predio {code_main}: Riesgo Medio ({score}). {reasons}")

                    # PUNTOS DEL PREDIO, en el orden de su índice de vértice
                    req = QgsFeatureRequest().setFilterExpression(f"\"{self.config['FIELDS']['NODO']}\" = '{nodo_val}'")
                    idx_v = l_pts.fields().indexOf(self.config['FIELDS']['VERTEX_INDEX'])
                    puntos_predio = [p for p in l_pts.getFeatures(req) if p.hasGeometry()]

                    def _orden(p):
                        try:
                            return int(float(p.attributes()[idx_v]))
                        except Exception:
                            return 0
                    puntos_predio.sort(key=_orden)

                    lote = next((l for l in ctx.lotes if l.nodo == nodo_val), None)
                    if lote is None:
                        self.log_error(geom.centroid().asPoint(), "LOTE_SIN_GEOMETRIA", 0, "Revisar el polígono del levantamiento")
                        failures += 1
                        continue
                    verts = [(p.geometry().asPoint().x(), p.geometry().asPoint().y()) for p in puntos_predio]
                    lejos = [v for v in verts if lote.geom.exterior.distance(shapely.Point(v)) > 0.20]
                    if len(verts) < 3 or lejos:
                        self.log_error(geom.centroid().asPoint(), "PUNTOS_NO_COINCIDEN", len(lejos),
                                       "La capa de coordenadas no tiene los vértices de este predio; vuelva a extraerlos")
                        failures += 1
                        continue

                    # MOTOR: mira hacia afuera de cada lado y decide con quién colinda
                    lados = analizar_lote(lote, ctx, vertices=verts)

                    poly_report = {
                        'id': code_main,
                        'nodo': nodo_val,
                        'area': geom.area(),
                        'perimeter': geom.length(),
                        'segments': [],
                        'segments_detailed': []
                    }
                    n_lados = len(lados)
                    for lado, pt_feat in zip(lados, puntos_predio):
                        if self.stop_requested: break
                        segments_count += 1
                        seg_geom = QgsGeometry.fromPolylineXY([QgsPointXY(*lado.p1), QgsPointXY(*lado.p2)])
                        self.visual_feedback.emit(seg_geom)
                        tramo_tag = f"V{lado.indice} - V{lado.indice % n_lados + 1}"
                        conf = nivel_conf(lado)
                        if lado.longitud < 0.02:
                            continue
                        if lado.colindante == "NO_ENCONTRADO" or lado.confianza == "BAJA":
                            mid = seg_geom.interpolate(lado.longitud / 2).asPoint()
                            self.log_error(mid, "REVISAR_COLINDANTE", lado.separacion,
                                           f"{lado.colindante} ({int(round(lado.fraccion * 100))}% del lado)")
                            failures += 1

                        attrs = {
                            'COLINDANTE': lado.colindante,
                            'LINDERO': lado.lindero,
                            'PUNTO_CARD': lado.cardinal,
                            'DESCRIPCIO': lado.descripcion[:254],
                            'NIVEL_CONF': conf
                        }
                        for f, v in attrs.items():
                            idx = l_pts.fields().indexOf(f)
                            if idx != -1: l_pts.changeAttributeValue(pt_feat.id(), idx, v)

                        poly_report['segments'].append(f"{lado.lindero}: {lado.descripcion}")
                        poly_report['segments_detailed'].append({
                            'idx': lado.indice,
                            'tramo': tramo_tag,
                            'orientacion': lado.lindero,
                            'cardinal': lado.cardinal,
                            'length': round(lado.longitud, 2),
                            'colindante': lado.colindante,
                            'confianza': conf,
                            'score': int(round(lado.fraccion * 100)),
                            'narracion': lado.descripcion
                        })

                        now_t = time.time()
                        elapsed_sec = now_t - start_time
                        speed_val = segments_count / max(0.2, elapsed_sec)
                        rem_segs = max(0, total_segments_expected - segments_count)
                        eta_sec = rem_segs / max(0.1, speed_val)
                        elapsed_str = f"{int(elapsed_sec//60):02d}:{int(elapsed_sec%60):02d}"
                        eta_str = f"{int(eta_sec//60):02d}:{int(eta_sec%60):02d}"
                        metodo = {"LOTE": "LOTE VECINO DEL LEVANTAMIENTO", "TERRENO": "PREDIO CATASTRAL VECINO",
                                  "MISMO": "RESTO DEL MISMO PREDIO", "VIA": "VÍA / ESPACIO PÚBLICO"}.get(lado.tipo, "SIN DATO")
                        step_data = {
                            'predio_id': code_main, 'nodo': nodo_val,
                            'step': lado.indice, 'total_steps': n_lados,
                            'predio_idx': i + 1, 'total_predios': total,
                            'tramo_label': f"V{lado.indice} ➔ V{lado.indice % n_lados + 1}",
                            'distancia': round(lado.longitud, 2), 'cardinal': lado.cardinal,
                            'colindante': lado.colindante, 'score': int(round(lado.fraccion * 100)),
                            'confianza': conf, 'metodo': metodo,
                            'geom': seg_geom, 'bbox': seg_geom.boundingBox(),
                            'elapsed_str': elapsed_str, 'eta_str': eta_str, 'speed': round(speed_val, 1)
                        }
                        self.step_inspected.emit(step_data)
                        self.stats_updated.emit({
                            'elapsed_seconds': int(elapsed_sec), 'elapsed_str': elapsed_str,
                            'eta_seconds': int(eta_sec), 'eta_str': eta_str, 'speed': round(speed_val, 1),
                            'predios_done': i + 1, 'total_predios': total,
                            'segments_done': segments_count, 'total_segments': total_segments_expected
                        })
                        if status_manager:
                            status_manager.update_step(step_data)
                            status_manager.update_status(
                                predios=i+1, total_predios=total, segments=segments_count, errors=failures,
                                progress=int((segments_count / max(1, total_segments_expected)) * 100),
                                task=f"V{lado.indice}➔V{lado.indice % n_lados + 1}: {lado.colindante}",
                                elapsed=int(elapsed_sec), eta=int(eta_sec), speed=round(speed_val, 1)
                            )
                        QApplication.processEvents()
                        if self.is_paused:
                            while self.is_paused and not self.stop_requested:
                                if self.step_trigger:
                                    self.step_trigger = False
                                    break
                                QApplication.processEvents()
                                time.sleep(0.04)
                        elif self.delay_ms > 0:
                            time.sleep(self.delay_ms / 1000.0)
                            QApplication.processEvents()

                    self.reports.append(poly_report)
                
                except Exception as inner_e:
                    failures += 1
                    self.log_error(geom.centroid().asPoint(), "ERROR_PROCESO", 0, str(inner_e))
                    continue
            
            # 3. FASE TRAMOS (Ahora se llama al final, pero debería respetar los nodos ya escritos)
            # La función calculate_tramos ya agrupa por NODO internamente, así que es segura.
            self.progress_changed.emit(90, "Calculando Tramos...")
            self.calculate_tramos(l_pts)
            
            # VALIDACIÓN DE CIERRE
            closure_errors = self.validate_closure(self.reports)
            report_path = self.save_report(self.reports, closure_errors)

            # GUARDAR EN HISTORIAL
            try:
                elapsed = int(time.time() - start_time)
                summary = {
                    'predio_id': 'BATCH' if len(self.reports) > 1 else (self.reports[0]['id'] if self.reports else 'UNKNOWN'),
                    'total_predios': len(self.reports),
                    'total_segments': sum(len(r.get('segments', [])) for r in self.reports),
                    'total_errors': failures + len(closure_errors),
                    'elapsed_seconds': elapsed,
                    'status': 'completed_with_errors' if failures > 0 else 'success',
                    'config': self.config
                }
                
                # Preparar resultados detallados
                results_data = []
                for r in self.reports:
                    results_data.append({
                        'predio_id': r['id'],
                        'colindantes': [s['colindante'] for s in r.get('segments', [])],
                        'errors': [e for e in closure_errors if r['id'] in e],
                        'warnings': [],
                        'geometry': None # Opcional: serializar geometría si es necesario
                    })
                
                history.save_analysis(summary, results_data)
                logger.info("Análisis guardado en historial")
                
                # EXPORTAR A SQL (Enterprise)
                try:
                    sql_path = os.path.join(os.path.dirname(report_path), "colindante_export.sql")
                    
                    # Enriquecer datos para SQL
                    sql_data = []
                    for r in self.reports:
                        # Recuperar geometría original si es posible, o usar centroide/bbox
                        # Aquí simplificamos usando WKT del primer segmento o NULL si no hay
                        geom_wkt = None
                        # TODO: Pasar geometría real desde el loop principal
                        
                        sql_data.append({
                            'predio_id': r['id'],
                            'colindantes': [s['colindante'] for s in r.get('segments', [])],
                            'errors': [e for e in closure_errors if r['id'] in e],
                            'quality_score': 0, # Se podría pasar el score del predictor
                            'geometry': geom_wkt
                        })
                        
                    if db_connector.generate_sql_dump(sql_data, sql_path):
                        logger.info(f"Exportación SQL generada: {sql_path}")
                        
                except Exception as sql_err:
                    logger.error(f"Error generando SQL: {sql_err}")
                    
            except Exception as h_err:
                logger.error(f"Error guardando historial: {h_err}")

            if l_pts.commitChanges():
                msg = f"Proceso Finalizado.\nReporte guardado en: {report_path}"
                if failures > 0: msg += f"\n\n{failures} inconsistencias detectadas."
                if closure_errors: msg += f"\n\nALERTA: {len(closure_errors)} errores de cierre."
                
                # Abrir reporte HTML automáticamente
                try:
                    import webbrowser
                    # Intentar usar el servidor HTTP si está disponible para evitar bloqueos de seguridad del navegador
                    try:
                        from .simple_server import http_server
                        http_server.set_latest_report(report_path)
                        url = http_server.get_report_url()
                        logger.info(f"Abriendo reporte en: {url}")
                        webbrowser.open(url)
                    except:
                        # Fallback a archivo local si falla el servidor
                        webbrowser.open('file://' + report_path)
                except:
                    pass
                    
                self.finished.emit(True, msg)
            else:
                l_pts.rollBack()
                self.finished.emit(False, "Error al guardar cambios.")

        except Exception as e:
            traceback.print_exc()
            self.finished.emit(False, str(e))

    def prepare_fields(self, layer):
        pr = layer.dataProvider()
        needed = ['COLINDANTE', 'TRAMO', 'DISTANCIA', 'LINDERO', 'PUNTO_CARD', 'DESCRIPCIO', 'NIVEL_CONF']
        for f in needed:
            if layer.fields().indexOf(f) == -1:
                if f == 'DISTANCIA':
                    fld = QgsField(f, QMetaType.Type.Double); fld.setLength(20); fld.setPrecision(2)
                else:
                    fld = QgsField(f, QMetaType.Type.QString); fld.setLength(254)
                pr.addAttributes([fld])
        layer.updateFields()

    def _contexto_motor(self, layers, selection, margen=80.0):
        """Predios, vías y lotes como geometrías shapely para el motor de colindantes."""
        def a_shapely(g):
            s = shapely.force_2d(shapely.from_wkb(bytes(g.asWkb())))
            return shapely.make_valid(s) if not s.is_valid else s

        caja = QgsRectangle()
        for f in selection:
            caja.combineExtentWith(f.geometry().boundingBox())
        caja.grow(margen)
        req = QgsFeatureRequest().setFilterRect(caja)

        campo_vec = self.config['FIELDS']['VECINO']
        terrenos = [(str(f.attribute(campo_vec)), a_shapely(f.geometry()))
                    for f in layers['TERRENO'].getFeatures(req) if f.hasGeometry()]

        vias = []
        if 'VIAS' in layers:
            campos = [f.name() for f in layers['VIAS'].fields()]
            campo_via = next((c for c in ['texto', 'TEXTO', 'nombre', 'NOMBRE', 'name', 'NAME', 'etiqueta',
                                          'ETIQUETA', 'via', 'VIA'] if c in campos), None)
            for f in layers['VIAS'].getFeatures(req):
                if f.hasGeometry():
                    vias.append((str(f.attribute(campo_via) or "VIA PUBLICA") if campo_via else "VIA PUBLICA",
                                 a_shapely(f.geometry())))

        campo_nodo, campo_cod = self.config['FIELDS']['NODO'], self.config['FIELDS']['PROTAGONISTA']
        campos_lev = [f.name() for f in layers['LEVANTAMIENTO'].fields()]
        campo_dir = next((c for c in ('NOMENCLATU', 'DIRECCION', 'direccion') if c in campos_lev), None)
        lotes = []
        for f in layers['LEVANTAMIENTO'].getFeatures():
            if not f.hasGeometry():
                continue
            g = a_shapely(f.geometry())
            if g.geom_type == 'MultiPolygon':
                g = max(g.geoms, key=lambda p: p.area)
            if g.geom_type != 'Polygon' or g.is_empty:
                continue
            lotes.append(Lote(str(f.attribute(campo_nodo)), str(f.attribute(campo_cod) or ""), g, "",
                              str(f.attribute(campo_dir) or "") if campo_dir else ""))
        return Contexto(terrenos=terrenos, vias=vias, lotes=lotes)

    def calculate_tramos(self, layer):
        idx_n = layer.fields().indexOf(self.config['FIELDS']['NODO'])
        idx_v = layer.fields().indexOf(self.config['FIELDS']['VERTEX_INDEX'])
        if idx_n == -1 or idx_v == -1: return
        
        groups = {}
        for p in layer.getFeatures():
            try:
                val_n = str(p.attributes()[idx_n])
                raw_v = p.attributes()[idx_v]
                val_v = int(float(raw_v)) if raw_v is not None else 0
                groups.setdefault(val_n, []).append({'id': p.id(), 'idx': val_v, 'geom': p.geometry()})
            except: continue
            
        for node_id, items in groups.items():
            items.sort(key=lambda x: x['idx'])
            count = len(items)
            if count < 2: continue
            for i, item in enumerate(items):
                expected = i + 1
                if item['idx'] != expected:
                    layer.changeAttributeValue(item['id'], idx_v, expected)
                    item['idx'] = expected
            for k in range(count):
                curr = items[k]
                next_p = items[(k+1)%count]
                
                # Validar geometrías antes de calcular distancia
                if curr['geom'] is None or curr['geom'].isEmpty() or next_p['geom'] is None or next_p['geom'].isEmpty():
                    logger.warning(f"Geometría nula en nodo {node_id}, punto {curr['idx']}")
                    continue
                
                try:
                    dist = round(curr['geom'].asPoint().distance(next_p['geom'].asPoint()), 2)
                    layer.changeAttributeValue(curr['id'], layer.fields().indexOf('TRAMO'), f"{curr['idx']} AL {next_p['idx']}")
                    layer.changeAttributeValue(curr['id'], layer.fields().indexOf('DISTANCIA'), dist)
                except Exception as e:
                    logger.error(f"Error calculando tramo {curr['idx']}: {str(e)}")
                    continue

    def validate_closure(self, reports):
        errors = []
        for r in reports:
            total = sum([float(re.search(r'extensión de ([\d,]+)', s).group(1).replace(',','.')) for s in r['segments'] if 'extensión de' in s])
            if abs(total - r['perimeter']) > 0.1:
                errors.append(f"Lote {r['id']}: Error de cierre {abs(total - r['perimeter']):.2f}m")
        return errors

    def save_report(self, reports, errors):
        """Genera un reporte notarial ejecutivo con diseño premium y certificación de cierre perimetral"""
        logger.info("Generando reporte notarial ejecutivo de alta precisión")
        
        output_dir = self.proj.homePath() if self.proj.homePath() else os.path.expanduser("~")
        report_path = os.path.join(output_dir, "reporte_notarial_colindantes.html")
        
        try:
            now_str = datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")
            total_predios = len(reports)
            total_tramos = sum(len(r.get('segments', [])) for r in reports)
            
            # Construir HTML ejecutivo
            predios_html = ""
            for r in reports:
                pid = r.get('id', 'N/A')
                area_m2 = f"{r.get('area', 0.0):.2f}"
                perim_m = f"{r.get('perimeter', 0.0):.2f}"
                
                rows_html = ""
                detailed = r.get('segments_detailed', [])
                if detailed:
                    for s in detailed:
                        badge_color = "#10b981" if "EXACTO" in s.get('confianza', '') else ("#00f2ff" if s.get('score', 0) > 70 else "#f59e0b")
                        rows_html += f"""
                        <tr>
                            <td style="font-weight:700; color:#00f2ff;">{s.get('tramo', '-')}</td>
                            <td><span style="background:rgba(0,242,255,0.15); color:#00f2ff; padding:3px 8px; border-radius:4px; font-weight:700;">{s.get('orientacion', '-')}</span></td>
                            <td style="color:#94a3b8;">{s.get('cardinal', '-')}</td>
                            <td style="font-weight:700; text-align:right;">{s.get('length', 0.0):.2f} m</td>
                            <td style="font-weight:700; color:#fff;">{s.get('colindante', '-')}</td>
                            <td><span style="background:{badge_color}22; color:{badge_color}; border:1px solid {badge_color}44; padding:3px 8px; border-radius:12px; font-size:11px; font-weight:600;">{s.get('confianza', '-')}</span></td>
                            <td style="color:#cbd5e1; font-size:11.5px; font-style:italic;">{s.get('narracion', '-')}</td>
                        </tr>
                        """
                else:
                    for s_txt in r.get('segments', []):
                        rows_html += f"<tr><td colspan='7' style='color:#e2e8f0;'>{s_txt}</td></tr>"

                closure_status = "<span style='color:#10b981; font-weight:700;'>✓ CIERRE PERIMETRAL VÁLIDO (Tolerancia ≤ 0.10m)</span>"
                for err in errors:
                    if str(pid) in str(err):
                        closure_status = f"<span style='color:#f43f5e; font-weight:700;'>⚠ {err}</span>"
                        break

                predios_html += f"""
                <div class="parcel-card">
                    <div class="parcel-header">
                        <div>
                            <h2 style="font-size:18px; color:#fff; font-weight:800;">PREDIO REF: {pid}</h2>
                            <p style="font-size:12px; color:#94a3b8;">Superficie: <b>{area_m2} m²</b> | Perímetro: <b>{perim_m} m</b></p>
                        </div>
                        <div>{closure_status}</div>
                    </div>
                    <table class="cadastral-table">
                        <thead>
                            <tr>
                                <th>TRAMO</th>
                                <th>COSTADO</th>
                                <th>RUMBO</th>
                                <th style="text-align:right;">DISTANCIA</th>
                                <th>COLINDANTE DETERMINADO</th>
                                <th>FIABILIDAD</th>
                                <th>DESCRIPCIÓN TÉCNICA NOTARIAL</th>
                            </tr>
                        </thead>
                        <tbody>
                            {rows_html}
                        </tbody>
                    </table>
                </div>
                """

            html_content = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dictamen Notarial de Colindancias | Colindante Elite</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {{ margin:0; padding:0; box-sizing:border-box; }}
        body {{ font-family:'Outfit', sans-serif; background:#0b111e; color:#e2e8f0; padding:40px; }}
        .container {{ max-width:1200px; margin:0 auto; }}
        .header {{ display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #1e293b; padding-bottom:24px; margin-bottom:30px; }}
        .title h1 {{ font-size:26px; font-weight:800; color:#fff; }}
        .title p {{ font-size:13px; color:#00f2ff; font-weight:600; letter-spacing:1px; }}
        .meta-box {{ text-align:right; font-size:12px; color:#94a3b8; }}
        .metrics-banner {{ display:grid; grid-template-columns:repeat(4, 1fr); gap:16px; margin-bottom:30px; }}
        .kpi {{ background:#131d31; border:1px solid #1e2a42; border-radius:12px; padding:16px; text-align:center; }}
        .kpi-lbl {{ font-size:11px; text-transform:uppercase; color:#94a3b8; font-weight:700; }}
        .kpi-val {{ font-size:24px; font-weight:800; font-family:'JetBrains Mono', monospace; color:#00f2ff; margin-top:4px; }}
        .parcel-card {{ background:#131d31; border:1px solid #1e2a42; border-radius:16px; padding:24px; margin-bottom:28px; box-shadow:0 10px 30px rgba(0,0,0,0.3); }}
        .parcel-header {{ display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #1e293b; padding-bottom:14px; margin-bottom:16px; }}
        .cadastral-table {{ width:100%; border-collapse:collapse; font-size:13px; }}
        .cadastral-table th {{ background:#0e1626; color:#94a3b8; text-transform:uppercase; font-size:11px; font-weight:700; padding:12px 10px; border-bottom:2px solid #1e293b; text-align:left; }}
        .cadastral-table td {{ padding:12px 10px; border-bottom:1px solid #1e293b; }}
        .cadastral-table tr:hover {{ background:rgba(255,255,255,0.02); }}
        .actions {{ display:flex; justify-content:flex-end; gap:12px; margin-bottom:20px; }}
        .btn {{ padding:10px 20px; border-radius:8px; font-family:inherit; font-size:13px; font-weight:700; cursor:pointer; text-decoration:none; display:inline-flex; align-items:center; gap:8px; }}
        .btn-print {{ background:#00f2ff; color:#000; border:none; }}
        .btn-print:hover {{ background:#00c8d6; }}
        @media print {{
            body {{ background:#fff; color:#000; padding:10px; }}
            .actions {{ display:none; }}
            .parcel-card {{ background:#fff; border:1px solid #ccc; box-shadow:none; color:#000; }}
            .kpi {{ background:#f8fafc; border:1px solid #ccc; }}
            .kpi-val {{ color:#0284c7; }}
            .cadastral-table th {{ background:#f1f5f9; color:#334155; }}
            .cadastral-table td {{ border-color:#e2e8f0; color:#000; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="actions">
            <button class="btn btn-print" onclick="window.print()">🖨️ IMPRIMIR / EXPORTAR A PDF</button>
        </div>
        <div class="header">
            <div class="title">
                <h1>DICTAMEN TÉCNICO Y NOTARIAL DE COLINDANCIAS</h1>
                <p>COLINDANTE ELITE &bull; CERTIFICACIÓN ESPACIAL DE ALTA PRECISIÓN</p>
            </div>
            <div class="meta-box">
                <p>Fecha de Expedición: <b>{now_str}</b></p>
                <p>Sistema: <b>Algoritmo Milimétrico Topológico</b></p>
                <p>Tolerancia de Cierre: <b>±0.10 m</b></p>
            </div>
        </div>

        <div class="metrics-banner">
            <div class="kpi">
                <div class="kpi-lbl">Predios Validados</div>
                <div class="kpi-val">{total_predios}</div>
            </div>
            <div class="kpi">
                <div class="kpi-lbl">Tramos Analizados</div>
                <div class="kpi-val">{total_tramos}</div>
            </div>
            <div class="kpi">
                <div class="kpi-lbl">Inconsistencias</div>
                <div class="kpi-val" style="color:{'#10b981' if not errors else '#f43f5e'};">{len(errors)}</div>
            </div>
            <div class="kpi">
                <div class="kpi-lbl">Conformidad Legal</div>
                <div class="kpi-val" style="color:#10b981;">100%</div>
            </div>
        </div>

        {predios_html}
    </div>
</body>
</html>
"""
            with open(report_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
                
            # Registrar en el gestor de estado para el dashboard
            if status_manager:
                status_manager.add_history_record({
                    'report_path': report_path,
                    'total_predios': total_predios,
                    'total_tramos': total_tramos,
                    'errors_count': len(errors)
                })

            return report_path
        except Exception as e:
            logger.error(f"Error generando reporte HTML: {e}")
            fallback_p = os.path.join(output_dir, "reporte_colindantes.html")
            with open(fallback_p, 'w', encoding='utf-8') as f:
                f.write(f"<html><body><h1>Reporte generado</h1><p>{str(e)}</p></body></html>")
            return fallback_p

    def _send_geometries_to_dashboard(self, status_manager, geometries):
        """Convierte geometrías QGIS a GeoJSON y las envía al dashboard"""
        try:
            from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject
            import json
            
            # Transformar a WGS84 (EPSG:4326) para el mapa web
            source_crs = QgsProject.instance().crs()
            dest_crs = QgsCoordinateReferenceSystem('EPSG:4326')
            transform = QgsCoordinateTransform(source_crs, dest_crs, QgsProject.instance())
            
            features = []
            for geom_data in geometries:
                try:
                    # Copiar y transformar geometría
                    geom = QgsGeometry(geom_data['geometry'])
                    geom.transform(transform)
                    
                    # Convertir a GeoJSON
                    geojson_geom = json.loads(geom.asJson())
                    
                    feature = {
                        "type": "Feature",
                        "properties": {
                            "id": geom_data['id'],
                            "height": min(30, max(10, geom_data['area'] / 10)),  # Altura basada en área
                            "area": round(geom_data['area'], 2)
                        },
                        "geometry": geojson_geom
                    }
                    features.append(feature)
                except Exception as e:
                    logger.error(f"Error convirtiendo geometría {geom_data['id']}: {e}")
                    continue
            
            # Crear FeatureCollection
            geojson = {
                "type": "FeatureCollection",
                "features": features
            }
            
            # Enviar al status_manager
            status_manager.update_status(current_geometry=geojson)
            
        except Exception as e:
            logger.error(f"Error enviando geometrías al dashboard: {e}")

class ForensicValidator:
    def __init__(self): self.vals = []
    def observe(self, v): self.vals.append(v)
    def is_anomaly(self, v):
        if len(self.vals)<10: return False
        try: return (v - statistics.mean(self.vals))/statistics.stdev(self.vals) < -1.5 and v < 1.0
        except: return False
